Thanks for downloading FlexGRID by VolumeThemes

We don't use any CSS hacks or JavaScript to create the equal column height awesomeness of FlexGRID. The only JavaScript included is the jQuery library and respond.js - providing you with IE8 support.

Don't forget to spread the news :)